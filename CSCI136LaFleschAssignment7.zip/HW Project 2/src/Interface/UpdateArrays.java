package Interface;

import javax.swing.ImageIcon;

import Children.Booby;

public interface UpdateArrays 
{
	
	public void updateBoobyArray(Booby[] myBoobyArray, ImageIcon[] myBoobyImageArray);

}
